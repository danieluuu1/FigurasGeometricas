public interface FiguraGeometrica {
    double calcularArea();
}
